%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                            MIO_SCAMPTOOL                            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% A Matlab package for advanced treatement and graphics of the SCAMP data
%%% MIO_SCAMPTOOL developed at MIO-Mediterranean Institute of Oceanography, 
%%% Marseille (France)
%%%
%%% MIO_SCAMPTOOLS is based on the orginal sofware SCAMPTOOL sold by PME 
%%% with the instrument
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 26/02/2014 AD : release of the 2.0 version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Credits : andrea.doglioli@univ-amu.fr (AD)
%%%           anne.petrenko@univ-amu.fr (AP)
%%%           yculod@locean-ipsl.umpc.fr (YC)
%%%           deny.malengros@univ-amu.fr (DM)
%%%           romain_raynaud@yahoo.com (RR)
%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% Contents of MIO_SCAMPTOOL package
%
% mio_analyze_save
%  |-mio_scamptool_param
%  |-mio_analyze
%     |-s_process
%     |    |-s_batfit OR mys_batfit 
%     |-epsilon_Thorpe 
%
% mio_plot
%
% mio_plot_stats
%
% SCAMP < SCAMP.mat (GUI  by PME)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                 end                                 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
