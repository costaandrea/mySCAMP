%===============================================================================
% MODULE S_SERVICE:  RESPOND TO USER ACTIVITY ON SCAMP_DISPLAY FIGURE
% FILE:  S_SERVICE.M
% REVISION: 1.00
% DISTRIBUTION: SCAMP OWNERS 
%-------------------------------------------------------------------------------
% COPYRIGHT 2004 PRECISION MEASUREMENT ENGINEERING  -  ALL RIGHTS RESERVED
% 31-JAN-04 Revision 1.00: Initial Release - copied from SCAMP.M with mods
% 01-APR-04 Revision 1.01: Minor bug fix for length(seg)
%
%          Programmed by: M. HEAD
%-------------------------------------------------------------------------------
%   DESCRIPTION:
%   This function responds to user activity on SCAMP_DISPLAY screen.
%
%==============================================================================*/
%
%------------------------------------------------------------------------------*/
%   INITIALIZATION SERVICE
%------------------------------------------------------------------------------*/

   
%------------------------------------------------------------------------------*/
%   LOAD SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'load')
   
   
   %---user browse to profile---
	[profile_name,profile_path]=uigetfile('*.raw','SCAMP PROFILE');
	myfile=[profile_path profile_name]

   %---load and process profile---
	s_process;                              % fills workspace with processed data
   
   
   %---update figure title--- 
   hTitleStaticText = findobj(gcf,'Tag','TitleStaticText');
   set(hTitleStaticText,'String',profile_name);
   clear hTitleStaticText;
   
   %---select initial segment---
   iseg = 1;
   
   
   %---initialize radio buttons---
   hButton = findobj(gcf,'Tag','RadioButton1');
   set(hButton,'Max',1);
   set(hButton,'Min',0);
   set(hButton,'Value',1);
   
   hButton = findobj(gcf,'Tag','RadioButton2');
   set(hButton,'Max',1);
   set(hButton,'Min',0);
   set(hButton,'Value',0);
   clear hButton;
   
   IndepChan = DepthChan;
   
   
   %---initialize full-profile list---
   %   Notes:
   %   PopupChanName contains the names of 'on' and psuedo channels
   %   that are diplayed by the popup menus above each plot.
   %   Psuedo channels are only available in segment plots.
   %   PopupChanIndex, when indexed by the value returned from a 
   %   popup menu gives the index for ChanEU, ChanName, ChanUnit.
  
   clear PopupChanName;                  % the names that appear in pop-up menus
   clear PopupChanIndex;     % translation from pop-up index to actual channel #
   i = 1;
   for ichan = 1:1:length(ChanEU)        % Rev 1.01
      if length(ChanEU{ichan}) > 1
         PopupChanName{i}=ChanName{ichan};
         PopupChanIndex(i) = ichan;
         if ichan == SigTChan
            FPopup1IV = i;
         elseif ichan == GradFastTChan
            FPopup2IV = i;
         end
         i = i+1;
      end;
   end;
   
   
   %---update figure full-profile popups--- 
   hPopup = findobj(gcf,'Tag','FullPopup1');
   set(hPopup,'String','\Default');
   set(hPopup,'String',PopupChanName);
   set(hPopup,'Value',FPopup1IV);
   
   hPopup = findobj(gcf,'Tag','FullPopup2');
   set(hPopup,'String','\Default');
	set(hPopup,'String',PopupChanName);
   set(hPopup,'Value',FPopup2IV);
   
   %---add psudo channels to list for segment use---
   PopupChanName{i} = ChanName{BatChan};
   PopupChanIndex(i)=BatChan;
   FPopup1IV = i;
   i=i+1;
   PopupChanName{i} = ChanName{LikelyhoodChan};
   PopupChanIndex(i)=LikelyhoodChan;
   FPopup2IV = i;
   i=i+1;
   
   %---update figure segment popups--- 
   hPopup = findobj(gcf,'Tag','SegPopup1');
   set(hPopup,'String','\Default');
   set(hPopup,'String',PopupChanName);
   set(hPopup,'Value',FPopup1IV);
  
   hPopup = findobj(gcf,'Tag','SegPopup2');
   set(hPopup,'String','\Default');
	set(hPopup,'String',PopupChanName);
   set(hPopup,'Value',FPopup2IV);
   
   clear PopupChanName;            %no longer needed, use ChanName{PopupIndex(x)}
   clear hPopup;
   clear FPopup1IV;
   clear FPopup2IV;
   
   command_str = 'replot';  % trick to get replotting done
end;

%------------------------------------------------------------------------------*/
%  PREVIOUS SEGMENT SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'prevseg')
   iseg = iseg-1;
   if iseg == 0
      iseg = 1;
   end;
   command_str = 'replot';  % trick to get replotting done
end;

%------------------------------------------------------------------------------*/
%  NEXT SEGMENT SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'nextseg')
   iseg = iseg+1;
   if iseg > length(seg)
      iseg = length(seg);
   end;
   command_str = 'replot';  % trick to get replotting done
end;


%------------------------------------------------------------------------------*/
%   DEPTH INDEPENDENT AXIS SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'depthindep')
   IndepChan = DepthChan;
   hButton = findobj(gcf,'Tag','RadioButton2');
   set(hButton,'Value',0);
   clear hButton;
   command_str = 'replot';  % trick to get replotting done
end;

%------------------------------------------------------------------------------*/
%   TIME INDEPENDENT AXIS SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'timeindep')
   IndepChan = TimeChan;
   hButton = findobj(gcf,'Tag','RadioButton1');
   set(hButton,'Value',0);
   clear hButton;
   command_str = 'replot';  % trick to get replotting done
   clear hAxes;
   clear hPopup;
   
end;


%------------------------------------------------------------------------------*/
%   LEFT FULL POPUP MENU SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'fullpopup1')
   
   %---left full-profile plot
   hPopup = findobj(gcf,'Tag','FullPopup1');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','FullAxes1');
   set(gcf,'CurrentAxes',hAxes); 
   Segmented = 0;
   s_plot;
   set(hAxes,'Tag','FullAxes1');
   clear hAxes;
   clear hPopup;
   
   
end;

%------------------------------------------------------------------------------*/
%   RIGHT FULL POPUP MENU SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'fullpopup2')
   
   %---right full-profile plot
   hPopup = findobj(gcf,'Tag','FullPopup2');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','FullAxes2');
   set(gcf,'CurrentAxes',hAxes); 
   Segmented = 0;
   s_plot;
   set(hAxes,'Tag','FullAxes2');
   clear hAxes;
   clear hPopup;

end;

%------------------------------------------------------------------------------*/
%   UPPER SEGMENTED POPUP MENU SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'segpopup1')
  
   hPopup = findobj(gcf,'Tag','SegPopup1');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','SegAxes1');
   set(gcf,'CurrentAxes',hAxes);
   Segmented = 1;
   s_plot;
   set(hAxes,'Tag','SegAxes1');  %wierd work-around!
   clear hAxes;
   clear hPopup;
end;

%------------------------------------------------------------------------------*/
%   LOWER SEGMENTED POPUP MENU SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'segpopup2')
  
   hPopup = findobj(gcf,'Tag','SegPopup2');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','SegAxes2');
   set(gcf,'CurrentAxes',hAxes);
   Segmented = 1;
   s_plot;
   set(hAxes,'Tag','SegAxes2');  %wierd work-around!
   clear hAxes;
   clear hPopup;
   
end;

%------------------------------------------------------------------------------*/
%   FULL RE-PLOT SERVICE
%------------------------------------------------------------------------------*/
if strcmp(command_str,'replot')
   
   %---establish independent axis
   hButton = findobj(gcf,'Tag','RadioButton1');
   if get(hButton,'Value') == 1
      IndepChan = DepthChan;
   else
      IndepChan = TimeChan;
   end
   clear hButton;
   
    
   %---left full-profile plot
   hPopup = findobj(gcf,'Tag','FullPopup1');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','FullAxes1');
   set(gcf,'CurrentAxes',hAxes); 
   Segmented = 0;
   s_plot;
   set(hAxes,'Tag','FullAxes1'); %wierd work-around!

   
   %---right full-profile plot---
   hPopup = findobj(gcf,'Tag','FullPopup2');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','FullAxes2');
   set(gcf,'CurrentAxes',hAxes)
   Segmented = 0;
   s_plot;
   set(hAxes,'Tag','FullAxes2'); %wierd work-around!

   
   %---upper segment plot---
   hPopup = findobj(gcf,'Tag','SegPopup1');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','SegAxes1');
   set(gcf,'CurrentAxes',hAxes)
   Segmented = 1;
   s_plot;
   set(hAxes,'Tag','SegAxes1');  %wierd work-around!
   
   %---lower segment plot
   hPopup = findobj(gcf,'Tag','SegPopup2');
   ichan = PopupChanIndex(get(hPopup,'Value'));
   hAxes = findobj(gcf,'Tag','SegAxes2');
   set(gcf,'CurrentAxes',hAxes)
   Segmented = 1;
   s_plot;
   set(hAxes,'Tag','SegAxes2');  %wierd work-around!
   
   clear hPopup;
   clear hAxes;
   
   %---display segment information---
   str1(1) = {sprintf('Segment %3.0f:  %3.2f to %3.2f  %s',iseg,...
         ChanEU{IndepChan}(seg(iseg).startscan+1),...
         ChanEU{IndepChan}(seg(iseg).stopscan),...
         ChanUnit{IndepChan})};
   hSegStaticText = findobj(gcf,'Tag','SegStaticText');
   set(hSegStaticText,'String',str1);
   clear hSegStaticText;
   
end;

   
   
%------------------------------------------------------------------------------*/
%   LOAD SERVICE
%------------------------------------------------------------------------------*/
   
   
%-----------------s_service ends-----------------------------------------------*/



