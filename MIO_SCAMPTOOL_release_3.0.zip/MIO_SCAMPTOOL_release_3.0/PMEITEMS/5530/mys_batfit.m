%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                            MIO_SCAMPTOOL                            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% mys_batfit.m (Matlab script)
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 24/02/2014 AD : release of the 2.0 version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% changes by Yannis Cuypers :
%%% 1) Luketina and Imberger when turbulence is very low
%%% 2) Stainbuck JAOT2009 for chi_T (a voir)
%%% 3) extention of K_b range starting at 45 instead of 80
%%%
%disp('s_batfit.m modified')
%%
%===============================================================================
% MODULE S_BATFIT:  DETERMINE KB FROM SCAMP PROFILE SEGMENT
% FILE:  S_BATFIT.M
% REVISION: 2.00
% DISTRIBUTION: SCAMP OWNERS ONLY
%--------------------------------------------------------------------------------
% COPYRIGHT 1998, 2004 PRECISION MEASUREMENT ENGINEERING  -  ALL RIGHTS RESERVED
% 03-FEB-04 Revision 2.00 - copied and adapted from SCAMP.M
%          Programmed by: M. HEAD
%--------------------------------------------------------------------------------
%DESCRIPTION:
%
%   This function estimates the Batchelor wavenumber from a SCAMP profile segment.
%   Estimation is accomplished by determining the kB such that the Batchelor
%   spectrum based on kB plus SCAMP noise best matches the power spectrum
%   observed from the segment in a maximum likelyhood sense.
%
%   REFERENCE:
%   Ruddick, Barry, Anis, Ayal, Thompson, Keith. 2000: 
%   Maximum Likelihood Spectral Fitting: The Batchelor Spectrum. 
%   Journal of Atmospheric and Oceanic Technology: Vol. 17, No. 11, pp. 1541�1555.
%==============================================================================*/
%   USEAGE:
%           [kB,X,V,R] = batfit(iseg);
%
%     iseg - index of segment to process             ()
%     kB   - batchelor wave number estimate          (cycles/meter)
%     X    - rate of destruction of thermal variance ((deg C)^2/sec)
%     V    - variance of kB estimate                 (?)
%     R    - quality of kB estimate                  (?)
%
%
%   This function accesses varables in the matlab desktop global space
%
%==============================================================================*/
%   NOTES:
%
%   This function uses FFT power spectrum estimation techniques.
%   The FFT algrothim assumes that the spatial domain samples provided as input
%   to the routine are sampled at equal distances in space.  This is accomplished
%   in a simple way by assuming that SCAMP's velocity throughout the segment
%   was constant, = localV.  For many SCAMP segments this assumption is 
%   essentially correct.  However SCAMP segments where velocity varies 
%   substantially exist, and will be incorrectly estimated by this function.
%   A more advanced spectrum estimation technique is being worked on at the
%   time of this writing.  Contact PME.
%
%   Every call to this function will produce a kB.  Since not every segment
%   in a profile will result from fluid motions that can be described by
%   a Batchelor spectrum, not every kB will be valid.  It is very desirable
%   to determine a quality factor, Q, that can be used to distinguish good
%   estimations from bad.  This function has a Q variable output, but it
%   is trivial.  Further research is needed to establish a good Q.
%
%==============================================================================*/

%------------------------------------------------------------------------------*/
%   I.  ESTIMATE POWER SPECTRUM OF SEGMENT DATA
%------------------------------------------------------------------------------*/
%   Note: this estimator is FFT based and depends upon equally-spaced
%         samples.  A better estimator that can deal with non-equally
%         spaced samples is desirable.
%------------------------------------------------------------------------------*/

%---estimate segment velocity---
seg_vel_array = s_getseg(ChanEU{VelChan},...
                         seg(iseg).startscan,seg(iseg).stopscan);
localV = abs(s_repvel(seg_vel_array));         %MAJOR e ERROR HERE!!!
clear seg_vel_array;


%---estimate segment power spectrum---
seg_g_fast_t = s_getseg(ChanEU{GradFastTChan},...
                        seg(iseg).startscan,seg(iseg).stopscan);

[PSD, freq_m, dof]  = s_psd(seg_g_fast_t,nFFT,rate/localV,window,overlap);

clear seg_g_fast_t;            


%------------------------------------------------------------------------------*/
%   II. ESTIMATE POWER SPECTRUM OF SCAMP ELECTRONIC NOISE
%------------------------------------------------------------------------------*/

%---find electronic noise estimate this segment---
noise  = s_snoise(freq_m*localV, noise_parameter, noise_floor,...
   fast_t_sharp, fast_t_smooth, BW, filter);

%---express noise in wave number space---
noise = noise/localV;          %(deg c/s)^2/hz -> (deg c/m)^2/(cyc/m)
 Dt   = 1.4E-7;
%Dt = 1.0E-7;
 V_k  = 1.0E-6; 
%V_k = 1.9E-6;
Pr=V_k/Dt;
Cstar=0.04;  
%---------------------------------------------------------
%   III.  COARSE KB ESTIMATION
%---------------------------------------------------------
ikB=1;
%for kB=75.0 : 5.0 : 800.0;           % search e range: 10e-10 to 1e-5
for kB=40.0 : 5.0 : 800.0;           % search e range: 8e-12 to 1e-5		 
	%---find begin/end of valid spectral region this segment---
	start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));%v-c transition
	stop_index  = s_blimit(freq_m,BW/localV);            %filter cutoff
	PSD_bat     = s_getseg(PSD,   start_index, stop_index);
	noise_bat   = s_getseg(noise, start_index, stop_index);
	freq_m_bat  = s_getseg(freq_m,start_index, stop_index);
	X           = s_X(PSD_bat, noise_bat, freq_m_bat);

    %ajout Yannis d'apr�s Steinbuck JAOT 2009
    eps=100;
    niter=0;
    while eps>0.1&niter<10;
	Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
    kstar=Cstar*Pr^(-0.5)*kB;
    [a,imin]=min(abs(freq_m_bat-kstar)); %on determine le nombre d'onde min pour int�gration sur donn�es
    [a,imax]=min(abs(log10(noise_bat)-log10(Batchelor_spect))); %on determine l'indice imax du point d'intersection bruit spectre k(imax)=knoise 
    if imin==1;  Slw=(PSD_bat-noise_bat); else Slw=Batchelor_spect; end 
    if imax==length(Batchelor_spect); Shw=0; else Shw=Batchelor_spect; end   

    X=6*Dt*(sum(Slw(1:imin))*mean(diff(freq_m_bat))+...
    sum(PSD_bat(imin+1:imax)-noise_bat(imin+1:imax))*mean(diff(freq_m_bat))+...
    sum(Shw(imax+1:end))*mean(diff(freq_m_bat))); %on calcule X en prenant le spectre de Batchelor pour k>knoise
    eps=sum(abs(Batchelor_spect-s_bspect(freq_m_bat, X, kB, q)));    
    niter=niter+1;
    %figure(10);  loglog(PSD_bat); hold on; loglog(Batchelor_spect,'r');
    %pause
    end
    %%%%fin ajout Yannis
    Batchelor_spect = Batchelor_spect+noise_bat;
		
	%---compute likelyhood this kB, this segment---
   likelyhood(ikB) = s_c11(PSD_bat, Batchelor_spect, dof);
	kBs(ikB)=kB;
		
	%---end this kB fit attempt, this segment---    
	ikB = ikB+1;
	end;
		
%---pick the most likely one---
[kB_likelyhood,ikB]  = max(likelyhood);
kB = kBs(ikB);                                         % coarse estimate of kB!!

%Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
%X=trapz(freq_m_bat,PSD_bat);



%------------------------------------------------------------------------------*/
%   IV.  FINE KB ESTIMATION
%------------------------------------------------------------------------------*/
ikB=1;
for kB=kB-10.0 : 1.0 : kB+10.0;                        % search around coarse kB
	 
	%---compute Batchelor fit at kB this segment---
	start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));%v-c transition
	stop_index  = s_blimit(freq_m,BW/localV);            %filter cutoff
	PSD_bat    = s_getseg(PSD,   start_index, stop_index);
	noise_bat  = s_getseg(noise, start_index, stop_index);
	freq_m_bat = s_getseg(freq_m,start_index, stop_index);
	X = s_X(PSD_bat, noise_bat, freq_m_bat);
    
    %ajout Yannis d'apr�s Steinbuck JAOT 2009
    
    eps=100;
    niter=1;
    while eps>0.1 &niter<10
	Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
    kstar=Cstar*Pr^(-0.5)*kB;
    [a,imin]=min(abs(freq_m_bat-kstar)); %ondetermine le nombre d'onde min pour int�gration sur donn�es
    [a,imax]=min(abs(log10(noise_bat)-log10(Batchelor_spect))); %on determine l'indice imax du point d'intersection bruit spectre k(imax)=knoise 
    if imin==1;  Slw=(PSD_bat-noise_bat); else Slw=Batchelor_spect; end 
    if imax==length(Batchelor_spect); Shw=0; else Shw=Batchelor_spect; end
    X=6*Dt*(sum(Slw(1:imin))*mean(diff(freq_m_bat))+...
    sum(PSD_bat(imin+1:imax)-noise_bat(imin+1:imax))*mean(diff(freq_m_bat))+...
    sum(Shw(imax+1:end))*mean(diff(freq_m_bat))); %on calcule X en prenant le spectre de Batchelor pour k>knoise
    eps=sum(abs(Batchelor_spect-s_bspect(freq_m_bat, X, kB, q)));
    niter=niter+1;
    %pause
    %pause
    end
    %%%%fin ajout Yannis
      
    
	Batchelor_spect = Batchelor_spect+noise_bat;
		
	%---compute likelyhood this kB, this segment---
   likelyhood(ikB) = s_c11(PSD_bat, Batchelor_spect, dof);
	kBs(ikB)=kB;
		
	%---end this kB fit attempt, this segment---    
	ikB = ikB+1;
	end;
		
%---pick the most likely one---
[kB_likelyhood,ikB]  = max(likelyhood);
kB = kBs(ikB);                                           % fine estimate of kB!! 
	
   
%-----------------------------------------------------------------------------*/
%   V. INTERPOLATION OF LIKELYHOOD
%-----------------------------------------------------------------------------*/
p=polyfit(kBs,likelyhood,3);  
manykBs =  kB-10.0 : 0.01 : kB+10.0;
pp=polyval(p,manykBs);
[kB_likelyhood,ikB]  = max(pp);
kB = manykBs(ikB);                        %final kB estimate, 0.01 resolution!!!


%-----------------------------------------------------------------------------*/
%   VI. FINIALIZE BATCHELOR SPECTRUM
%-----------------------------------------------------------------------------*/
%---recompute Batchelor fit at best kB this segment---
start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));
stop_index  = s_blimit(freq_m,BW/localV);
PSD_bat     = s_getseg(PSD,   start_index, stop_index);
noise_bat   = s_getseg(noise, start_index, stop_index);
freq_m_bat  = s_getseg(freq_m,start_index, stop_index);
Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
Batchelor_spect = Batchelor_spect+noise_bat;
% 
% figure
% loglog(freq_m_bat,PSD_bat)
% hold on
% loglog(freq_m_bat,Batchelor_spect,'r')

%-----------------------------------------------------------------------------*/
%   VII. FINAL ESTIMATION OF X
%-----------------------------------------------------------------------------*/
X = s_X(PSD_bat, noise_bat, freq_m_bat);


%-----------------------------------------------------------------------------*/
%   VIII. ESTIMATE VARIANCE OF KB
%-----------------------------------------------------------------------------*/
der2=polyder(polyder(p));
pp = polyval(der2,manykBs);
V = -1/pp(ikB);


%-----------------------------------------------------------------------------*/
%   IX.  DETERMINE QUALITY FACTOR
%-----------------------------------------------------------------------------*/
R=var((PSD_bat./Batchelor_spect));  %AC

%s_fig3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Ajout Yannis
if Luke_a==1
 [maxN,i]=max(noise_bat);
 [maxPSD,j]=max(PSD_bat);
 %if (abs(i-j)<40)&(log10(maxPSD)-log10(maxN))<1; Rseg(iseg)=1000;  end 
 if (abs(i-j)<40)&(log10(maxPSD)-log10(maxN))<1; %si le max du bruit est proche du max du spectre de batchelor (en fr�quen ce et en eamplitude)=> pb de fit=>technique laternative  
 Depth=ChanEU{DepthChan}; Depth=Depth(seg(iseg).startscan+1:seg(iseg).stopscan+1);...
     [eps,Chi,myR,kB,Batchelor_spect]=BatchSpec(PSD_bat,freq_m_bat,noise_bat,Depth); seg_kB(iseg,1)=kB;...%on utilise la methode de fit de Luketina et Imberger
         if(Chi<0|Chi>0.1); R=1000; else R=0;  end
    
     %pause
 end    
end


%%%%%%%%%%%%%%%%%%
%Alternative formulation for K_z  TO CHECK!!


temp = ChanEU{GradFastTChan};
seg_temp_array = temp(seg(iseg).startscan+1:seg(iseg).stopscan);

seg_Tz = mean( seg_temp_array );


Kz_alt = 0.5 * X ./ seg_Tz^2;

%-----------------------------------------------------------------------------*/
%   X.  CALCULATE MAD2   (by AC) 30/10/14
%--------------------------------------------------------------------------
%---*/
 
 Sth=Batchelor_spect;
 Sobs=PSD_bat;
 
   ratio_mean=mean(Sobs./Sth);
    
 MAD2 = mean( abs( Sobs./Sth - ratio_mean ) );
 %MAD2(MAD2==0)=NaN;
 
 %-----------------------------------------------
 n=numel(Sth);
 
 SNR = sum(PSD_bat./noise(1:numel(PSD_bat))); %AC 28/01
 %sgn = Sobs(1:imax)./noise(1:imax); %AC 23/01
 
 
 %-----------------------------------------------------------------------------*/
%   XI.  CALCULATE C11   (by AC) 30/10/14
%--------------------------------------------------------------------------
%---*/

C11 = s_c11(PSD_bat, Batchelor_spect, dof);

 
 %-----------------------------------------------------------------------------*/
%   XII.  CALCULATE LHR   (by AC) 30/10/14
%--------------------------------------------------------------------------
%---*/
%%%A*k^(-b) + noise_bat;

  p=polyfit(log(freq_m_bat),log(PSD_bat),2);
  PowL = log(freq_m_bat).^p(1)+p(2);  
  PnPowL = s_c11(log(PSD_bat),PowL,dof);
  C11log=s_c11(log(PSD_bat),log(Batchelor_spect),dof);

  LHR = exp(C11log-PnPowL);

  % % figure
% % plot(freq_m_bat,PSD_bat)
% % hold on
% % plot(freq_m_bat,nPowL,'r')
  	

%-----------------------------------------------------------------------------*/
%   XIII.  CALCULATE adimensional spectrum   (by AC) 15/12/14
%--------------------------------------------------------------------------
%---*/
imax=numel(freq_m_bat);
y=zeros(1,imax);
Etb=zeros(1,imax);

ei=2*pi*kB^4.0*V_k*Dt^2.0; %epsilon in this segment
kdt=sqrt(sqrt( ei/(V_k*Dt^2) )); %normalizing factor

phi=kdt/sqrt(2*q);
y=freq_m_bat(1:imax)./phi; %freq adim
%Etb=(1./y).*exp((-y.^2)./2);    %theoretical Batchelor adim spectrum

%Ekr=(1+sqrt(3)*y)./y.*exp(-sqrt(3)*y); %theoretical Kraichnan adim spect

EtbTH=y.*( exp(-y.^2/2) - y.*sqrt(pi/2).*(erf(y./sqrt(2))) );

EkrTH=y.*exp(-sqrt(3).*y);

Etb=(Batchelor_spect(1:imax)-noise(1:imax)).*(X./(2*Dt*phi));%check this

%cutty=find(freq_m_bat==cut)
%Etb(cutty:end)=0; %cut noisy tail  - check!!!


%Ekr=

EbG = (Batchelor_spect(1:imax)-noise(1:imax))/X*(ei*V_k)^(3/4);
yG = freq_m_bat(1:imax)*(V_k^3/ei)^(1/4)*sqrt(Dt/V_k);

  








%-----------------batfit.m ends-----------------------------------------------*/
