%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                            MIO_SCAMPTOOL                            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% s_process.m (Matlab script)
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 24/02/2014 AD : release of the 2.0 version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% 20/02/2014 AD : added estimation of thorpe dispalcement of the segment
%%% 12/02/2014 AD : Loading of mio_scamptools_param added to run mofied s_process
%%% 31/01/2014 AD : removed the addpath commands by romain
%%% 23/07/2013 AD AP DM : fixed a small bug by RR in the test of direction
%%% 22/03/2012 RR : test on direction profile added
%%%
%%% changes by Yannis Cupers
%%% 1) calls my_sbatfit and 
%%% 2) save R quality factor
%%%
disp('s_process.m modified')
%%
%===============================================================================
% MODULE S_PROCESS:  PROCESS CONTROL FOR USB SCAMP DATA ANALYSIS
% FILE:  S_PROCESS.M
% REVISION: 1.02
% DISTRIBUTION: SCAMP OWNERS 
%-------------------------------------------------------------------------------
% COPYRIGHT 2004 PRECISION MEASUREMENT ENGINEERING  -  ALL RIGHTS RESERVED
% 31-JAN-04 Revision 1.00.0: Initial Release - copied from SCAMP.M with mods
%
%          Programmed by: M. HEAD
%-------------------------------------------------------------------------------
%   DESCRIPTION:
%   This program processes SCAMP profiles.  The program coordiates user selection
%   of the file, loads the file, and computes various full-profile and segmented
%   results.  These remain in the Matlab desktop after this program completes
%   its operations.
%
%   This program is compatable with all SCAMP data files.
%
%   Initialize myfile with path and file name prior to calling s_process.
%   Review processing parameters to be sure they implement your desires!!
%
%=============================================================================*/
%    STANDARD SCAMP CHANNEL ASSIGNMENTS
%
%
%    CHANNEL       STANDARD FUNCTION          STANDARD UNITS
%    -------       -----------------          --------------
%      0           FAST T0                     (deg C)
%      1           FAST T1                     (deg C)
%      2           FAST C                      (mS/cm)
%      3           uDO                         (Volts) 
%      4           ACCURATE C                  (mS/cm)
%      5           ACCURATE T                  (deg C)
%      6           T OF FAST CT CIRCUIT        (deg C)
%      7           FLUOROMETER                 (Volts)
%      8           PAR                         (umol/(sec m^2))
%     14           DEPTH                       (meters)
%     16           GRAD FAST T0                (deg C/sec)
%     17           GRAD FAST T1                (deg C/sec)
%
%    NOTES:	 The processing methods and subroutines used within this module
%            assume that the channels and units are as shown here.
%            If channel assignments or units are changed on the SCAMP Microprofiler,
%            care must be taken to insure that this processing software continues
%            to operate properly.  Channel assignments are, of course, critical
%            since this software assumes the above channel list is actually implemented
%            by SCAMP.  Some of the units listed above are also critical since density
%            and other computations assume that the numbers they receive (and produce)
%            are given in the units shown.
%
%            Matlab does not recognize array index of 0.  However all SCAMP mex files
%            do recognize array index 0.  This program contains statements that 
%            patch this inconsistency.
%
%
%    REFERENCES:
%            Most processing is accomplished by mex files called by this 
%            program.  Each mex file is supplied with a *.m file that 
%            gives the useage, processing method implemented, and reference.
%    
%
%==============================================================================*/
%
% REVISION: 1.01  01-APR-2004
%           Added processing parameter and code to select segmentation methods
%           Added equal interval segmentation ability
%
% REVISION: 1.02  20-OCT-2004
%           Channel trim failed with data_start > 0 since trimming of 'off'
%           channels (length of 1) was attempted.  Modified the program to
%           skip trimming of off channels.
%   
%
%------------------------------------------------------------------------------*/
%   I.   INITIALIZATION
%------------------------------------------------------------------------------*/

mio_scamptool_param %%AD : Loading of mio_scamptools_param

%clf;
%clear;
clear ChanEU;
clear ChanName;
clear ChanUnit;
clear seg;

%-------------------------------
%   Directory Initializations
%
%   Set this path to the location where
%   the SCAMP toolbox is placed.
%-------------------------------

%-------------------------
%   Physical Constants
%-------------------------
pi   = 3.14159;                    %ratio of circle circumference to diameter ()
Dt   = 1.4E-7;                              % temperature diffusivity (M**2/sec)
Ds   = 1.4E-9;                                     % salt diffusivity (M**2/sec)
V_k  = 1.0E-6;                                   % kinematic viscosity (M^2/sec)
grav = 9.78049;                         % accel of gravity, (M/sec**2) (Z +down)


%---------------------------
%    SCAMP Parameters
%
%    These parameters describe the 
%    SCAMP hardware.
%---------------------------
%  parameters that are the same for all SCAMPs
rate            = 100.000;                 % SCAMPS scanning rate (scans/second)
filter          = 45.0;                   %SCAMP's anti-alias filter cutoff (hz)
ADMAXCHAN       = 32;                      %number of channels possible in SCAMP

% parameters describing individual SCAMPs
% (should be adjusted to match individual SCAMP)
noise_parameter = 8.0E-12;                          %SCAMP's noise prior to d/dt
noise_floor     = 4.0E-9;                     %SCAMP's noise after d/dt & filter


%-----------------------------------------------------------
%   Channel List for ChanEU, ChanName, ChanUnit Index
%
%   Channels 1 to 32 are SCAMP direct measurement.
%   (Note that other SCAMP software uses 0 as first channel.)
%   Channels 33 and up are derrived channels.
%-----------------------------------------------------------
%---measured channels
FastT0Chan      = 1;                      %Fast T0                       (deg C)
FastT1Chan      = 2;                      %Fast T1                       (deg C)
FastCChan       = 3;                      %Fast C                        (mS/cm)
uDOChan         = 4;                      %uDO                           (Volts) 
AccCChan        = 5;                      %Acc C                         (mS/cm)
AccTChan        = 6;                      %Acc T                         (deg C)
FMeterChan      = 8;                      %Fluorometer                   (Volts)
PARChan         = 9;                      %PAR                  (umol/(sec m^2))
DepthChan       = 15;                     %Depth                        (meters)
GradFastT0Chan  = 17;                     % Grad Fast T0             (deg C/sec)
GradFastT1Chan  = 18;                     %Grad Fast T1              (deg C/sec)

%---derrived channels
TimeChan        = 33;                     %time channel from SCAMP     (seconds)
VelChan         = 34;                     %velocity channel         (meters/sec)
SigTChan        = 35;                     %density-1000                 (kg/m^3)
SalChan         = 36;                     %salinity (if CChan exists)      (PPT)
SortSigTChan    = 37;                     %density-stable sorted Sigma-T(kg/m^3)
BVChan          = 38;                     %Brunt-Vaisala Frequency       (1/sec)
ThorpeChan      = 39;                     %Thrope displacement          (meters)
GPrimeChan      = 40;                     %Gravity Anomolie    (meters/second^2)
LcChan          = 41;                     %Centered Length Scale        (meters)
ddtChan         = 42;                     %statistical distance               ()

%---psuedo channel assignment---
BatChan         = 43;                     %batchelor psuedo-channel
LikelyhoodChan  = 44;                     %kB likelyhood psuedo-channel


%-----------------------------------
%   Processing Channel Assignment
%
%   This table selects actual channels
%   to be used for subsequent processing.
%   Change the RHS arguments to select 
%   other channels.
%
%   Example:
%   TChan = FastT0Chan;    
%   causes density, salinity to be computed
%   from Fast T0 sensor information.
%-----------------------------------
FastTChan       = FastT0Chan;           %channel providing Fast Temperature info
GradFastTChan   = GradFastT0Chan;            %channel providing Grad Fast T info
TChan           = AccTChan;      %channel providing t info for density, salinity
CChan           = AccCChan;      %channel providing c info for density, salinity
IndepChan       = DepthChan;                     %select the independent channel


%--------------------------------------------------------
%   Processing Parameters 
%
%   various parameters that control subsequent processing
%--------------------------------------------------------
%  general parameters
MAXSCANS        = 120000;                %max this program can process!! (scans)

%  sensor bandwidth compensation & filtering
fast_t_sharp    = 12.5;                           %1-pole sharpening begins (hz)
fast_t_smooth   = 40.0;                             %1-pole sharpening ends (hz)
BW              = 40.0;                        %overall multipole filtering (hz)
depthBW         = 6.25;                            %depth channel filtering (hz)
velBW           = 0.25;                         %velocity channel filtering (hz)

%  segmentation
%%%AD moved to mio_scamptool_param %%%SegmentMethod   = 'ddt';               %select segment method: 'ddt' or 'scans'
%%%AD moved to mio_scamptool_param %%%SCANSperSEG     = 500;        % # scans per seg in 'scans' segmentation (scans)
nslide          = 256;               %grad_fast_t mean removal avg width (scans)
nvel            = 50;                    %#points in d_depth/dt estimate (scans)
nWinWidth       = 64;                                %width of AR window (scans)
nAROrder        = 4;                              %order of AR fit polynomial ()
spike_threshold = 400.0;               %dd_dt threshold for segment ends (dd_dt)
spike_minsep    = 128;               %merge dd_dt spikes within this dist (scan)
spike_minlength = 4;                          %ignore narrow dd_dt spikes (scan)
segment_minsize = 128;                                %min segment length (scan)
segment_maxsize = 2024;
%segment_maxsize = 8192;                               %max segment length (scan)

%  spectral resolution
%nFFT            = 64;                         %# frequencies in PSD estimator ()
nFFT            = 256;
window          = 2;                                    %fft window 2=hanning ()
overlap         = 1;                             %1/2 overlap of fft segments ()

%  turbulence
q               = 3.4;                                %Batchelor PSD constant ()
cstar           = 0.04;                         %inertial-conv to viscus-conv ()


%------------------------------------------------------------------------------*/
%   II.  LOAD CALIBRATED PROFILE DATA 
%------------------------------------------------------------------------------*/
%   NOTES:
%   This section loads all possible SCAMP hardware channels.
%   For 'on' channels, the channel name, units, and engineering unit (EU)
%   data are loaded.  For 'off' channels only the name and units are
%   loaded.  ChanEU for these channels is filled with only one element,
%   having 0.0 value.
%
%   ChanEU contains the channel calibrated engineering units.
%     For example ChanEU{FastT0Chan} will contain numbers like 22.3 with units 
%      deg C 
%
%   This section determines if the data file is an original type or 
%   from the USB SCAMP.  The appropriate loader is called depending
%   on the type.
%------------------------------------------------------------------------------*/
%---user browse to profile---
%[profile_name,profile_path]=uigetfile('*.raw','SCAMP PROFILE');
%myfile=[profile_path profile_name]

%---load all SCAMP channels---
h = waitbar(0,'Loading SCAMP Data...');

if (profile_name(1)=='_')                                   % if old data format
   for ichan=1:1:ADMAXCHAN;
      waitbar(ichan/ADMAXCHAN);
   	[ChanEU{ichan},ChanName{ichan},ChanUnit{ichan}] = s_load1(myfile,ichan-1);
	end;
   [ChanEU{TimeChan},ChanName{TimeChan},ChanUnit{TimeChan}] = s_load1(myfile,-1);
else                                                            % new data format
   for ichan=1:1:ADMAXCHAN;
      waitbar(ichan/ADMAXCHAN);
   	[ChanEU{ichan},ChanName{ichan},ChanUnit{ichan}] = s_load2(myfile,ichan-1);
	end;
   [ChanEU{TimeChan},ChanName{TimeChan},ChanUnit{TimeChan}] = s_load2(myfile,-1);
end;

close(h); 


%---error trap channels some must exist!---
if(length(ChanEU{FastTChan})==1)
   msgbox('Fast T channel not present','Channel Error','error');
   error('Channel not present!');
end;

if(length(ChanEU{GradFastTChan})==1)
   msgbox('Gradient Fast T channel not present','Channel Error','error');
   error('Channel not present!');
end;

if(length(ChanEU{TChan})==1)
   msgbox('Temperature channel not present','Channel Error','error');
   error('Channel not present!');
end;

if(length(ChanEU{DepthChan})==1)
   msgbox('Depth channel not present','Channel Error','error');
   error('Channel not present!');
end;

%---error trap since we don't know what size arrays Matlab can handle
if(length(ChanEU{TimeChan}) > MAXSCANS)
   msgbox('Exceeds MAXSCANS','Data Volume Warning','warn');
   error('MAXSCANS exceeded!');
end;

clear mex;   



%------------------------------------------------------------------------------*/
%   III.  TRIM PROFILE 
%------------------------------------------------------------------------------*/
%   NOTES:
%   Profiles typically have problems when they begin or end.  Examples are
%   no SCAMP velocity at profile start, or sensors out of water at profile end.
%   This section allows trimming of the profiles to remove start or end bad 
%   data.  However the trimming implemented here is trivial.
%   Some trimming algrothim should be developed at a future time.
%------------------------------------------------------------------------------*/

% %%%---determine proper trimming points (trivial example implemented)---
% data_start = 0;
% data_stop  = length(ChanEU{TimeChan});

%---determine profile type (upward or downward)--- (Modif RR 22/03/2012)
depth1=ChanEU{DepthChan};
test_depth=depth1(1)-depth1(end-1);
if test_depth<2         %downward profile
    %if test_depth<2         %downward profile %AC
    direction=0;
elseif test_depth>2     %upward profile
    direction=1;
else%%% i.e. test_depth==0 AD AP DM 22/07/2013
    disp('!!! no depth change, probably a test profile !!!')
    break
end
direction

%--- cut of the first meters --- modif RR
%--- 22/07/2013 AD AP DM : insertion of the variable  depth_cut_surf 
if direction==1
    depth_cut_surf = 1;
test_trim=find(ChanEU{DepthChan}<depth_cut_surf);
if isempty(test_trim)==1                %no trim if the 1st depth is upper than 4 m
    data_start = 0;
    data_stop  = length(ChanEU{TimeChan});
else
data_start = 0;
data_stop  = test_trim(1);
end
elseif direction==0
    depth_cut_surf = 4;
test_trim=find(ChanEU{DepthChan}>depth_cut_surf);
if isempty(test_trim)==1
    data_start = 0;
    data_stop  = length(ChanEU{TimeChan});
else
data_start = test_trim(1);
data_stop  = length(ChanEU{TimeChan});
end
end

%---trim the data---
for ichan=1:1:ADMAXCHAN;
   if(length(ChanEU{ichan})>1)         %trim only 'on' channels (Rev 1.02)
      ChanEU{ichan} = s_getseg(ChanEU{ichan},data_start,data_stop);
      end;
end;
ChanEU{TimeChan} = s_getseg(ChanEU{TimeChan},data_start,data_stop);

clear mex;  

%------------------------------------------------------------------------------*/
%   IV.  DE-TREND GRADIENT DATA 
%------------------------------------------------------------------------------*/
%   NOTES:
%   Sections below apply spectral analysis to gradient data.  DC offsets in
%   the data that result from slight processing circuit errors and from
%   background average temperature gradients in real measurements
%   can produce large amounts of 0 frequency energy.  This section removes
%   gradient data offsets.
%------------------------------------------------------------------------------*/
ChanEU{GradFastTChan} = s_smean(ChanEU{GradFastTChan},nslide);


%---clean up this section
clear mex;   



%------------------------------------------------------------------------------*/
%   V.  SENSOR BANDWIDTH COMPENSATION 
%------------------------------------------------------------------------------*/
%   NOTES:
%   Fast temperature sensors have limited time responses.
%   This section artifically increases sensor response by amplifying
%   higher frequencies.
%
%   SCAMP's depth channel is noisy.  Noise is removed by limiting the channel
%   bandwidth here.
%------------------------------------------------------------------------------*/

%---compensate direct channel
ChanEU{FastTChan} = s_bwcomp(ChanEU{FastTChan}, ChanEU{TimeChan},...
                             fast_t_sharp, fast_t_smooth);
ChanEU{FastTChan} = s_filter(ChanEU{FastTChan},ChanEU{TimeChan},BW);

%---compensate gradient channel
ChanEU{GradFastTChan} = s_bwcomp(ChanEU{GradFastTChan},...
                                 ChanEU{TimeChan}, fast_t_sharp, fast_t_smooth);
ChanEU{GradFastTChan} = s_filter(ChanEU{GradFastTChan}, ChanEU{TimeChan}, BW);

%---limit depth channel noise
ChanEU{DepthChan} = s_filter(ChanEU{DepthChan},ChanEU{TimeChan},depthBW);

%---clean up this section
clear mex;    


%------------------------------------------------------------------------------*/
%   VI. FULL-PROFILE CHANNEL PROCESSING
%------------------------------------------------------------------------------*/
%   NOTES:
%   There are other, derrived, full-profile channels that can be determined
%   from full-profile SCAMP data.  This section computes these derrived channels
%------------------------------------------------------------------------------*/
h = waitbar(0,'Processing Channels...');

%---compute velocity channel---
ChanName{VelChan} = 'Velocity';
ChanUnit{VelChan} = 'meters/sec';
ChanEU{VelChan} = s_vel(ChanEU{TimeChan},ChanEU{DepthChan}, nvel);
ChanEU{VelChan} = s_filter(ChanEU{VelChan},ChanEU{TimeChan},velBW);
waitbar(1/8);

%---compute sigma-t channel---
%   (freshwater users who record conductivity will have an error here!!)
ChanName{SigTChan} = 'Sigma-T';
ChanUnit{SigTChan} = 'kg/m^3';
if(length(ChanEU{CChan})==1)  %if no conductivity provided
   ChanEU{SigTChan}   = s_sigt(ChanEU{TChan});                     %freshwater
else                        %if conductivity provided
   ChanEU{SigTChan}   = s_sigt(ChanEU{TChan},ChanEU{CChan});       %seawater!!
end;
waitbar(2/8);

%---compute (if applicable) salinity channel---
ChanName{SalChan} = 'Salinity';
ChanUnit{SalChan} = 'PPT';
if(length(ChanEU{CChan})==1)  %if no conductivity provided
   ChanEU{SalChan}=1.0;                                         %dummy channel
else                        %if conductivity provided
   ChanEU{SalChan}   = s_sal(ChanEU{CChan},ChanEU{TChan});       %seawater!!
end;
waitbar(3/8);

%---clean up this section
clear mex;    



%------------------------------------------------------------------------------*/
%   VII. FULL-PROFILE CHANNEL PROCESSING OF DENSITY-STABLE CHANNELS
%------------------------------------------------------------------------------*/
%   NOTES:
%   Insight into physical processes may sometimes be obtained by sorting
%   measurements into a density-stable profile while recording the effective
%   vertical distances each scan element must be moved to achieve stability.
%   Various such channels are computed here.
%------------------------------------------------------------------------------*/

%--- find sorting dependent quantities ----
ChanName{SortSigTChan} = 'Sorted Sigma-T';
ChanUnit{SortSigTChan} = 'kg/m^3';
[ChanEU{SortSigTChan}, sort_depth, sort_vel] = s_sortd(ChanEU{SigTChan},...
                                                       ChanEU{DepthChan},...
                                                       ChanEU{VelChan});
waitbar(4/8);
                                                    
                                                    
%---compute Brunt-Vaisala channel---
%   Note that BV could be computed from the original Sigma-T but is instead 
%   computed here from sorted Sigma-T.  This approach is thought to give
%   a better estimation of background stability since it tends to remove
%   the dynamic effects of mixing.
ChanName{BVChan} = 'Brunt-Vaisala Frequency';
ChanUnit{BVChan} = '1/sec';
ChanEU{BVChan}   = s_bv(ChanEU{TimeChan}, sort_vel, ChanEU{SortSigTChan});
waitbar(5/8);



%---compute Thorpe channel---
ChanName{ThorpeChan} = 'Thorpe Displacements';
ChanUnit{ThorpeChan} = 'meters';
ChanEU{ThorpeChan}   = s_thorpe(ChanEU{DepthChan}, sort_depth);
waitbar(6/8);


%---compute Gravity Anomolie channel---
ChanName{GPrimeChan} = 'Gravity Anomaly';
ChanUnit{GPrimeChan} = 'meters/second^2';
ChanEU{GPrimeChan}   = s_gprime(ChanEU{SigTChan},ChanEU{SortSigTChan});
waitbar(7/8);


%---compute centered length scale channel---
ChanName{LcChan} = 'Centered Length Scale';
ChanUnit{LcChan} = 'meters';
ChanEU{LcChan}   = s_lc(ChanEU{DepthChan}, ChanEU{ThorpeChan});
waitbar(8/8);


%---clean up this section
clear sort_depth;
clear sort_vel;
clear mex;
close(h); 



%------------------------------------------------------------------------------*/
%   VIII. SPATIAL CONVERSION
%------------------------------------------------------------------------------*/
%   NOTES:
%   SCAMP electronic circuits make measurements at equal time intervals and find
%   time-based derrivatives for gradient channels.  Later segment processing
%   operates upon spatial gradients.  Conversion is accomplished
%   here.  Note that velocity noise enters the temperature signal at this point.
%------------------------------------------------------------------------------*/
ChanEU{GradFastTChan} = ChanEU{GradFastTChan}./ChanEU{VelChan}; 
ChanUnit{GradFastTChan} = 'deg C/m';                                  %new units!


%------------------------------------------------------------------------------*/
%   IX.  SEGMENTATION OF PROFILE INTO STATIONARY SEGMENTS
%------------------------------------------------------------------------------*/
%   NOTES:
%   Segmentation is the process of defining sequences of measurements
%   within the profile that are thought to come from the same physical event.
%   Different methods for defining segments are known.  
%   Definition of segments is known to affect the final dissipation estimate.
%   Users are encouraged to consider this section carefully.  Segmentation 
%   represents an important phase in data processing and further research
%   is encouraged!
%
%   See s_segmen.m for definition of the seg array.  Other segmentation 
%   schemes must produce a compatable seg array!!
%
%   Other methods:
%     Chen, H. , M. Hondzo, A. Rao,  Segmentation of temperature microstructure,  
%     Journal of Geophysical Research-Oceans, 107(C12), 2002.
%
%     Piera, J. , E. Roget, J. Catalan, Turbulent patch identification in 
%     microstructure profiles: A method based on wavelet denoising and Thorpe 
%     displacement analysis, J.  Atmos. and Oceanic Tech., 19 (9), 1390 -1402, 2002
%------------------------------------------------------------------------------*/
h = waitbar(0,'Segmenting...');
waitbar(.1);


%---implement ddt segmentation method---
if strcmp(SegmentMethod,'ddt')
   
	%---find statistical distance between sliding windows---
	ChanName{ddtChan}   = 'Statistical Distance';
	ChanUnit{ddtChan}   = 'n/a';

	ChanEU{ddtChan}     =  s_ddt(ChanEU{GradFastTChan}, nWinWidth, nAROrder, rate);
	waitbar(1/2);

	%---identify segments based on threshold value---
	%   Note: seg array is the output of this section and 
	%   defines segments for later processing.
	seg     =  s_segmen(ChanEU{ddtChan},...  
						  spike_threshold,spike_minsep, spike_minlength, ...
                    segment_minsize, segment_maxsize);
    rejectS=0;%AC        
	waitbar(2/2);

end;


%---implement scans segmentation method---
if strcmp(SegmentMethod,'scans')
  	waitbar(1/2);

	for iseg=1:1:length(ChanEU{TimeChan})/SCANSperSEG;
      seg(iseg).startscan = ((iseg-1)* SCANSperSEG);  % PME uses index 0!
      seg(iseg).stopscan  = seg(iseg).startscan+SCANSperSEG;
      if (seg(iseg).stopscan > length(ChanEU{TimeChan}))
         seg(iseg.stopscan) = length(ChanEU{TimeChan});
         end;
     end;
     rejectS=0;%AC  
     waitbar(2/2);
end;




%---implement overlapping segmentation method---


if strcmp(SegmentMethod,'scans_over')
    
    
     p=100-overlappo;
     n=round(SCANSperSEG/100*p); %number of non overlapping points 
    
    waitbar(1/2);
    
    %building start points
    startseg_a = [ 0:1:floor(length(ChanEU{TimeChan})/SCANSperSEG)-1 ]*SCANSperSEG;%round(length(ChanEU{TimeChan})/SCANSperSEG) ];
    startseg_b = startseg_a(1:end) + n;
    
    startseg_v = zeros(1,2*floor((length(ChanEU{TimeChan})/SCANSperSEG)));
    startseg_v(1,1:2:end) =  startseg_a;
    startseg_v(1,2:2:end) = startseg_b;
    
    %building stop points
    stoptseg_v = startseg_v + SCANSperSEG;
     
    %iseg=0;
    for iseg=1:1:2*floor((length(ChanEU{TimeChan})/SCANSperSEG))-2
        
        seg(iseg).startscan = startseg_v(iseg);
        seg(iseg).stopscan = stoptseg_v(iseg);
    
    end
    rejectS=0;%AC  
     waitbar(2/2);
end

%---implement variance checking segmentation method---
%%%%%%Check it in the case of bad profiles
if strcmp(SegmentMethod,'subs')
  	waitbar(1/2);
    
    rejectS=0; % number of segments rejected because of segmentation
    
    SCANSinSEG=1024; %let's say. just to be coherent with the reference.
    erase=[];
      for iseg=1:1:floor(length(ChanEU{TimeChan})/SCANSinSEG);
               
            seg(iseg).startscan = ((iseg-1)*SCANSinSEG);
            seg(iseg).stopscan = seg(iseg).startscan + SCANSinSEG;
              VARI=zeros(8,1);
              for k=1:8      %embed segmentation  %%1024/8=128
            
                  grad = ChanEU{GradFastTChan};  %temperature vertical gradient
                 gradLoc = grad( seg(iseg).startscan +1+ (k-1)*128 : ...
                                  (seg(iseg).startscan + (k-1)*128 +128) ); %subsegment. +1 needed because of non zero index
                                             
                 VARI(k) = var(gradLoc);        %calc variance subsegment
                                        
              end
              
                %remember the bad ones!
              if max(VARI)-min(VARI)<10 %rejection criteria in the reference

                  continue;    %=do not register a new seg(iseg).start(end)scan ignore this segment
              else

               erase(end+1)=iseg;
               
              end
              
              if (seg(iseg).stopscan > length(ChanEU{TimeChan}));
                   seg(iseg).stopscan = length(ChanEU{TimeChan});
              end

      end
      
     
      %numel(erase)
      %erase the bad ones
      if numel(erase)>0
      startscans=[seg.startscan];
      stopscans=[seg.stopscan];
    
      startscans(erase)=[];
      stopscans(erase)=[];

      %[seg.startscan]=[];
      %[seg.stopscan]=[];
      sta=num2cell(startscans);
      sto=num2cell(stopscans);
      [seg.startscan]=sta{:};
      [seg.stopscan]=sto{:};
      end
      
 rejectS=numel(erase)
      
end
%---(add other methods here!!)---%% really?? u want more?!!


%---clean up this section
clear mex;    
close(h); 


%------------------------------------------------------------------------------*/
%   X.   PROFILE SEGMENT PROCESSING - BATCHELOR SPECTRA FITTING ETC.
%------------------------------------------------------------------------------*/
%   NOTES:
%   This section determines a representative Batchelor wave number for
%   each segment identified within a profile.
%   Different methods for Batchelor fitting are known.
%   s_batfit.m is selected here.
%   
%   Other methods:
%   Luketina, D. and J. Imberger, Determining Turbulent Kinetic Energy
%   Dissipation from Batchelor Curve Fitting    
%   Journal of Atmospheric and Oceanic Technology, 1998.
%------------------------------------------------------------------------------*/
h = waitbar(0,'Finding Batchelor Fits...');

%---name these psuedo-channels for later plotting use---
ChanName{BatChan}          = 'Batchelor Fit';
ChanName{LikelyhoodChan}   = 'kB Likelihood';



    ym=zeros(200,200); %matrices for adim spectra NB 200 is usually sufficient
    yGm=zeros(200,200); 
    Etbm=zeros(200,200);
    EtbmTH=zeros(200,200);
    Ekrm=zeros(200,200);
    
   c=0;
   d=0;
   

for iseg=1:1:length(seg);
   
   %---estimate Kb this segment---
   %%% AD added parameter in mio_scamptool_param
   if batfit_type==1  %%% AD added parameter in mio_scamptool_param
      s_batfit;  %%% Batchelor's fit by PME
   elseif batfit_type==2
     mys_batfit;%%% Batchelor's fit by Yannis Cuypers (see script for info)
                 %%% !!!!! change it also in s_plot)
   else
       disp('please choose the batfit type' )
   end
                 
   seg_kB(iseg,1)  = kB;    % batchelor wave number estimate          (cycles/meter)
   seg_X(iseg,1)   = X;     % rate of destruction of thermal variance ((deg C)^2/sec)
   seg_kBV(iseg,1) = V;     % variance of kB estimate                 ([[kB]^2]?)
   Rseg(iseg,1)       = R;     % quality of kB estimate                  ([])
   
   seg_Kz_alt(iseg,1) = Kz_alt; %AC
   
   MAD2seg(1,iseg)= MAD2;    %Mean Average Deviation    %AC 25/1/15   
   
   LHRseg(1,iseg)= log10(LHR);      %Linear Likelyhood Ratio     %AC 30/10/14
%   LHRseg_pos(1,iseg)= LHR_pos;      %AC 28/01
%   LHR2seg(1,iseg)= LHR2;     %AC 
   kB_seg(iseg) = manykBs(ikB); %AC 
   
   C11seg(1,iseg)= C11;%C11    %AC 30/10/14
   SNRseg(1,iseg)= SNR; %AC 28/01 signal-noise ratio
%   C11plseg(1,iseg)= C11pl;      %C11 power law   %AC 27/01/15
%   R1seg(iseg,1) = R1;       %AC 30/10/14
  
    
%    ym(iseg,1:length(freq_m_bat))      = y';     % freq adim   %AC 15/12
%    EtbmTH(iseg,1:length(freq_m_bat))    = EtbTH';    %Th. Batchelor adim spec
%    EkrmTH(iseg,1:length(freq_m_bat))    = EkrTH';    %Th. Kraichnan adim spec
%    Etbm(iseg,1:length(freq_m_bat))    = Etb';    %Th. Batchelor adim spec
% %   Ekrm(iseg,1:length(freq_m_bat))    = Ekr';    %Th. Kraichnan adim spec
%         %%%%N.B. The mess 1:length(freq_m_bat) is due to the fact that the number
%         %%%%of resolved frequencies can vary. So I allocate an empty matrix and
%         %%%%then fill it in this not brilliant way. I'll have some zeros in the
%         %%%%plot...
   %keyboard
 PSD_bat_m(iseg,1:length(PSD_bat))=PSD_bat'; %AC 18/03 exp spectrum
 freqsm(iseg,1:length(freq_m))= freq_m'; %AC 18/03 frequencies of pozwer spectrum 
   
 ym(iseg,1:length(y))      = y';     % freq adim   %AC 15/12
 EtbmTH(iseg,1:length(EtbTH))    = EtbTH';    %Th. Batchelor adim spec
 Etbm(iseg,1:length(Etb))    = Etb';    %Th. Batchelor adim spec

   
   yGm(iseg,1:length(y))      = yG'; %freq adim Gibson
   EbGm(iseg,1:length(EbG))    = EbG';
   
   
   
   
   waitbar(iseg/length(seg));

 [maxN,i]=max(noise_bat);
 [maxPSD,j]=max(PSD_bat);

 noise_batN(iseg,1:length(PSD_bat))=noise_bat';
 PSDN(iseg,1:length(PSD_bat))=PSD_bat'; 
 kbat(iseg,1:length(PSD_bat))=freq_m_bat';
   
   %---find representative values this segment---
   seg_BV_array = s_getseg(ChanEU{BVChan},seg(iseg).startscan,seg(iseg).stopscan);
   seg_BV(iseg,1) = s_avg(seg_BV_array);         %NEED BETTER ESTIMATOR!!!
   clear seg_BV_array;
  
	seg_e(iseg,1)  = (2*pi*seg_kB(iseg))^4.0 * V_k * Dt^2.0;
	seg_Lk(iseg,1) = (V_k^3/seg_e(iseg))^0.25;  % Kolmogoroff length scale  AP 11.08.2010
	seg_Lo(iseg,1) = sqrt(seg_e(iseg)/seg_BV(iseg)^3);  % Ozmidov length scale AP 11.08.2010
	
%%%20/02/2014 AD : estimation of thorpe dispalcement of the segment
   seg_Thorpe_array = s_getseg(ChanEU{ThorpeChan},seg(iseg).startscan,seg(iseg).stopscan);
   seg_Thorpe(iseg,1) = s_avg(seg_Thorpe_array);         %????AD??? NEED BETTER ESTIMATOR!!!
   clear seg_Thorpe_array;
%%%20/02/2014 AD : estimation of depth of the segment
   seg_Depth_array = s_getseg(ChanEU{DepthChan},seg(iseg).startscan,seg(iseg).stopscan);
   seg_Depth(iseg,1) = s_avg(seg_Depth_array);         %??? NEED BETTER ESTIMATOR!!!
   clear seg_Depth_array;


end;                                                    %of processing this segment

close(h);


%-----------------s_process ends------------------------------------------------*/
% The MATLAB workspace now contains the basic profile information
% as full-profile arrays (indexed by scan) or as segmented profile
% arrays (indexed by segment).
% Users are encouraged to continue this story...
%-----------------s_profile ends------------------------------------------------*/
