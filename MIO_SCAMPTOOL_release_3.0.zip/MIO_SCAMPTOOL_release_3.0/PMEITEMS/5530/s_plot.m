%===============================================================================
% MODULE S_PLOT:  PLOT SCAMP CHANNEL OR PSEUDO CHANNEL
% FILE:  S_PLOT.M
% REVISION: 1.00
% DISTRIBUTION: SCAMP OWNERS 
%-------------------------------------------------------------------------------
% COPYRIGHT 2004 PRECISION MEASUREMENT ENGINEERING  -  ALL RIGHTS RESERVED
% 31-JAN-04 Revision 1.00.0: Initial Release - copied from SCAMP.M with mods
%
%          Programmed by: M. HEAD
%-------------------------------------------------------------------------------
%   DESCRIPTION:
%   This script plots SCAMP channels or psuedo channels;
%
%   Input parameters:
%       Segmented - 0=full profile, 1=segmented
%       iseg   - segment # or 0 if full profile
%       ichan - channel number (ChanEU index)
%       IndepChan - independent channel number (ChanEU index)
%       hAxes - axes to plot onto
%
%==============================================================================*/
%==============================================================================*/
%
%------------------------------------------------------------------------------*/
%   INITIALIZE DIRECTION
%------------------------------------------------------------------------------*/
%  NOTES:
%    Depth is considered + downwards in SCAMP depth engineering unit calibrations.
%    Normal plotting of data vs depth uses a reversed Y (depth) axis to give
%    the user a sense of the vertical nature of SCAMP profiles; shallower points
%    appear above deeper ones. 
%    It is desirable to maintain the vertical display when data are plotted
%    vs time.  In downwards profiles a reversed axis should be used showing
%    the first data topmost.  In upwards profiles however, a normal axis 
%    should be used since the first data are actually acquired at deeper points.

if IndepChan == TimeChan   
   if ChanEU{DepthChan}(length(ChanEU{DepthChan})) > ChanEU{DepthChan}(1)%if down
      ydirection = 'reverse';                      %reverse if time and downwards
   else
      ydirection = 'normal';                         % normal if time and upwards
   end
else  %if depth
   ydirection = 'reverse';                                    % reverse if depth
      
end


%------------------------------------------------------------------------------*/
%   FULL PROFILE SERVICE
%------------------------------------------------------------------------------*/
if Segmented == 0
   
  %---find segment limits for plotting---
  slimitX(1)       = min(ChanEU{ichan});
  slimitX(2)       = max(ChanEU{ichan});
  slimitY_start(1) = ChanEU{IndepChan}(seg(iseg).startscan+1);
  slimitY_start(2) = ChanEU{IndepChan}(seg(iseg).startscan+1);
  slimitY_stop(1)  = ChanEU{IndepChan}(seg(iseg).stopscan);
  slimitY_stop(2)  = ChanEU{IndepChan}(seg(iseg).stopscan);
  
  %---plot ddtChan---
  if ichan == ddtChan                                          
   	climitX(1) = spike_threshold;
		climitX(2) = spike_threshold;
		climitY(1) = ChanEU{IndepChan}(1);
   	climitY(2) = ChanEU{IndepChan}(length(ChanEU{IndepChan}));
   
  		h1=plot(ChanEU{ichan},ChanEU{IndepChan},...
      	slimitX,slimitY_start,slimitX,slimitY_stop,climitX,climitY);
  		set(h1,{'LineStyle'},{'-';'--';'--';'--'});
  		set(h1,{'Color'},{'b';'r';'r';'r'});
  
   else % normal channels
      h1=plot(ChanEU{ichan},ChanEU{IndepChan},...
         slimitX,slimitY_start,slimitX,slimitY_stop);
  		set(h1,{'LineStyle'},{'-';'--';'--'});
  		set(h1,{'Color'},{'b';'r';'r'});
     
   	clear climitX;
   	clear climitX;
   	clear climitY;
   	clear climitY;
   end;
   
set(gca,'YDir',ydirection);
xlabel(ChanUnit{ichan});
ylabel(ChanUnit{IndepChan});
str1(1) = {sprintf('Segment %3.0f',iseg)};
text( (max(ChanEU{ichan})+3*min(ChanEU{ichan}))/4,...
      ChanEU{IndepChan}(seg(iseg).startscan+1),...
             str1,'HorizontalAlignment','left');

clear str1;
clear h1;    
clear slimitX;
clear slimitX;
clear slimitY_start;
clear slimitY_start;
clear slimitY_stop;
clear slimitY_stop;

end;


%------------------------------------------------------------------------------*/
%   SEGMENTED SERVICE
%------------------------------------------------------------------------------*/
if Segmented == 1
   
   
   %==========================
   %  ddtChan service
   %==========================
   if     ichan == ddtChan
      
      %---create segment arrays for plotting---
      depArray   = s_getseg(ChanEU{ichan},...
         seg(iseg).startscan,seg(iseg).stopscan);
      indepArray = s_getseg(ChanEU{IndepChan},...
         seg(iseg).startscan,seg(iseg).stopscan);
 
  		climitX(1) = spike_threshold;
		climitX(2) = spike_threshold;
		climitY(1) = indepArray(1);
   	climitY(2) = indepArray(length(indepArray));
      
      %---plot ddtChan---
  		h1=plot(depArray,indepArray,climitX,climitY);
  		set(h1,{'LineStyle'},{'-';'--'});
  		set(h1,{'Color'},{'b';'r'});
		str1(1) = {sprintf('Threshold %4.0f',spike_threshold)};
      text( (max(depArray)+3*min(depArray))/4,...
         (max(indepArray)+3*min(indepArray))/4,...
         str1,'HorizontalAlignment','left');
      
      clear depArray;
   	clear indepArray;
   	clear h1;

     
   %==========================
   %  BatChan service
   %==========================
	elseif ichan == BatChan
      
      %---create segment arrays for plotting---
      s_batfit;

      
      %---plot the batchelor information---
      h1=loglog(freq_m,PSD,freq_m,noise,freq_m_bat,Batchelor_spect);
  		xlabel('k (cyc/m)')
  		ylabel('PSD ((deg C/m)^{2}/(cyc/m))');
  		str1(1) = {sprintf('R= %3.3f',R)};
  		str1(2) = {sprintf('X= %9.2e ((deg C)^{2}/sec)',X)};
  		text(min(freq_m),min(noise),...
         str1,'HorizontalAlignment','left');
  		clear str1;
  		clear h3;
  
      
   %==========================
   %  LikelihoodChan service
   %==========================
	elseif ichan == LikelyhoodChan
      
      %---create segment arrays for plotting---
      s_batfit;

      %---plot the likelihood information---
  		h1=plot(kBs,likelyhood);
  		xlabel('k_B (cyc/m)')
  		ylabel('C11 likelyhood')
  
  		str1(1) = {sprintf('k_B = %5.2f (cyc/m)',kB)};
  		str1(2) = {sprintf('e  = %9.2e (m^{2}/sec^{3})',(2*pi*kB)^4.0 * V_k * Dt^2.0)};
  		str1(3) = {sprintf('Vk_B = %9.2e (1/m^{2})',V)}; %Anya Rumyantseva 26 aug 2010 previous (m^{2}/sec)^{2}
  		text( (max(kBs)+min(kBs))/2,(max(likelyhood)+3*min(likelyhood))/4,...
         str1,'HorizontalAlignment','center');
      text(kB,kB_likelyhood,'\bullet');
      
      
  		clear str1;
  		clear h1;
  		clear slimitX;
  		clear slimitY_start;
  		clear slimitY_stop;

      
   %===============================
   %  normal segmented chan service
   %===============================

   else                                       % normal segmented channel service
      
   	%---create segment arrays for plotting---
   	depArray   = s_getseg(ChanEU{ichan},seg(iseg).startscan,seg(iseg).stopscan);
   	indepArray = s_getseg(ChanEU{IndepChan},seg(iseg).startscan,seg(iseg).stopscan);
      
   	%---plot 1---
   	h1=plot(depArray,indepArray);
   	set(h1,{'LineStyle'},{'-'});
   	set(h1,{'Color'},{'b'});
   	set(gca,'YDir',ydirection);
   	xlabel(ChanUnit{ichan});
   	ylabel(ChanUnit{IndepChan});
   
   	clear depArray;
   	clear indepArray;
   	clear h1;
     
   end
   

end;

%------------------------------------------------------------------------------*/
%   EXIT THIS SCRIPT
%------------------------------------------------------------------------------*/

clear ydirection;
   
%-----------------s_plot ends--------------------------------------------------*/



