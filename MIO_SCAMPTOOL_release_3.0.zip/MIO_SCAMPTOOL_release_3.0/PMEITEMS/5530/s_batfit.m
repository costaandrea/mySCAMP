%===============================================================================
% MODULE S_BATFIT:  DETERMINE KB FROM SCAMP PROFILE SEGMENT
% FILE:  S_BATFIT.M
% REVISION: 2.00
% DISTRIBUTION: SCAMP OWNERS ONLY
%--------------------------------------------------------------------------------
% COPYRIGHT 1998, 2004 PRECISION MEASUREMENT ENGINEERING  -  ALL RIGHTS RESERVED
% 03-FEB-04 Revision 2.00 - copied and adapted from SCAMP.M
%          Programmed by: M. HEAD
%--------------------------------------------------------------------------------
%DESCRIPTION:
%
%   This function estimates the Batchelor wavenumber from a SCAMP profile segment.
%   Estimation is accomplished by determining the kB such that the Batchelor
%   spectrum based on kB plus SCAMP noise best matches the power spectrum
%   observed from the segment in a maximum likelyhood sense.
%
%   REFERENCE:
%   Ruddick, Barry, Anis, Ayal, Thompson, Keith. 2000: 
%   Maximum Likelihood Spectral Fitting: The Batchelor Spectrum. 
%   Journal of Atmospheric and Oceanic Technology: Vol. 17, No. 11, pp. 1541�1555.
%==============================================================================*/
%   USEAGE:
%           [kB,X,V,R] = batfit(iseg);
%
%     iseg - index of segment to process             ()
%     kB   - batchelor wave number estimate          (cycles/meter)
%     X    - rate of destruction of thermal variance ((deg C)^2/sec)
%     V    - variance of kB estimate                 (?)
%     R    - quality of kB estimate                  (?)
%
%
%   This function accesses varables in the matlab desktop global space
%
%==============================================================================*/
%   NOTES:
%
%   This function uses FFT power spectrum estimation techniques.
%   The FFT algrothim assumes that the spatial domain samples provided as input
%   to the routine are sampled at equal distances in space.  This is accomplished
%   in a simple way by assuming that SCAMP's velocity throughout the segment
%   was constant, = localV.  For many SCAMP segments this assumption is 
%   essentially correct.  However SCAMP segments where velocity varies 
%   substantially exist, and will be incorrectly estimated by this function.
%   A more advanced spectrum estimation technique is being worked on at the
%   time of this writing.  Contact PME.
%
%   Every call to this function will produce a kB.  Since not every segment
%   in a profile will result from fluid motions that can be described by
%   a Batchelor spectrum, not every kB will be valid.  It is very desirable
%   to determine a quality factor, Q, that can be used to distinguish good
%   estimations from bad.  This function has a Q variable output, but it
%   is trivial.  Further research is needed to establish a good Q.
%
%==============================================================================*/

%------------------------------------------------------------------------------*/
%   I.  ESTIMATE POWER SPECTRUM OF SEGMENT DATA
%------------------------------------------------------------------------------*/
%   Note: this estimator is FFT based and depends upon equally-spaced
%         samples.  A better estimator that can deal with non-equally
%         spaced samples is desirable.
%------------------------------------------------------------------------------*/

%---estimate segment velocity---
seg_vel_array = s_getseg(ChanEU{VelChan},...
                         seg(iseg).startscan,seg(iseg).stopscan);
localV = abs(s_repvel(seg_vel_array));         %MAJOR e ERROR HERE!!!
clear seg_vel_array;


%---estimate segment power spectrum---
seg_g_fast_t = s_getseg(ChanEU{GradFastTChan},...
                        seg(iseg).startscan,seg(iseg).stopscan);

[PSD, freq_m, dof]  = s_psd(seg_g_fast_t,nFFT,rate/localV,window,overlap);

clear seg_g_fast_t;            


%------------------------------------------------------------------------------*/
%   II. ESTIMATE POWER SPECTRUM OF SCAMP ELECTRONIC NOISE
%------------------------------------------------------------------------------*/

%---find electronic noise estimate this segment---
noise  = s_snoise(freq_m*localV, noise_parameter, noise_floor,...
   fast_t_sharp, fast_t_smooth, BW, filter);

%---express noise in wave number space---
noise = noise/localV;          %(deg c/s)^2/hz -> (deg c/m)^2/(cyc/m)
	
   
%---------------------------------------------------------
%   III.  COARSE KB ESTIMATION
%---------------------------------------------------------
ikB=1;
for kB=75.0 : 5.0 : 800.0;           % search e range: 10e-10 to 1e-5
		 
	%---find begin/end of valid spectral region this segment---
	start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));%v-c transition
	stop_index  = s_blimit(freq_m,BW/localV);            %filter cutoff
	PSD_bat     = s_getseg(PSD,   start_index, stop_index);
	noise_bat   = s_getseg(noise, start_index, stop_index);
	freq_m_bat  = s_getseg(freq_m,start_index, stop_index);
	X           = s_X(PSD_bat, noise_bat, freq_m_bat);
	Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
	Batchelor_spect = Batchelor_spect+noise_bat;
		
	%---compute likelyhood this kB, this segment---
   likelyhood(ikB) = s_c11(PSD_bat, Batchelor_spect, dof);
	kBs(ikB)=kB;
		
	%---end this kB fit attempt, this segment---    
	ikB = ikB+1;
	end;
		
%---pick the most likely one---
[kB_likelyhood,ikB]  = max(likelyhood);
kB = kBs(ikB);                                         % coarse estimate of kB!!

%------------------------------------------------------------------------------*/
%   IV.  FINE KB ESTIMATION
%------------------------------------------------------------------------------*/
ikB=1;
for kB=kB-10.0 : 1.0 : kB+10.0;                        % search around coarse kB
	 
	%---compute Batchelor fit at kB this segment---
	start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));%v-c transition
	stop_index  = s_blimit(freq_m,BW/localV);            %filter cutoff
	PSD_bat    = s_getseg(PSD,   start_index, stop_index);
	noise_bat  = s_getseg(noise, start_index, stop_index);
	freq_m_bat = s_getseg(freq_m,start_index, stop_index);
	X = s_X(PSD_bat, noise_bat, freq_m_bat);
	Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
	Batchelor_spect = Batchelor_spect+noise_bat;
		
	%---compute likelyhood this kB, this segment---
   likelyhood(ikB) = s_c11(PSD_bat, Batchelor_spect, dof);
	kBs(ikB)=kB;
		
	%---end this kB fit attempt, this segment---    
	ikB = ikB+1;
	end;
		
%---pick the most likely one---
[kB_likelyhood,ikB]  = max(likelyhood);
kB = kBs(ikB);                                           % fine estimate of kB!! 
	
   
%-----------------------------------------------------------------------------*/
%   V. INTERPOLATION OF LIKELYHOOD
%-----------------------------------------------------------------------------*/
p=polyfit(kBs,likelyhood,3);  
manykBs =  kB-10.0 : 0.01 : kB+10.0;
pp=polyval(p,manykBs);
[kB_likelyhood,ikB]  = max(pp);
kB = manykBs(ikB);                        %final kB estimate, 0.01 resolution!!!


%-----------------------------------------------------------------------------*/
%   VI. FINIALIZE BATCHELOR SPECTRUM
%-----------------------------------------------------------------------------*/
%---recompute Batchelor fit at best kB this segment---
start_index = s_blimit(freq_m,cstar*kB/sqrt(V_k/Dt));
stop_index  = s_blimit(freq_m,BW/localV);
PSD_bat     = s_getseg(PSD,   start_index, stop_index);
noise_bat   = s_getseg(noise, start_index, stop_index);
freq_m_bat  = s_getseg(freq_m,start_index, stop_index);
Batchelor_spect = s_bspect(freq_m_bat, X, kB, q);
Batchelor_spect = Batchelor_spect+noise_bat;


%-----------------------------------------------------------------------------*/
%   VII. FINAL ESTIMATION OF X
%-----------------------------------------------------------------------------*/
X = s_X(PSD_bat, noise_bat, freq_m_bat);


%-----------------------------------------------------------------------------*/
%   VIII. ESTIMATE VARIANCE OF KB
%-----------------------------------------------------------------------------*/
der2=polyder(polyder(p));
pp = polyval(der2,manykBs);
V = -1/pp(ikB);


%-----------------------------------------------------------------------------*/
%   IX.  DETERMINE QUALITY FACTOR
%-----------------------------------------------------------------------------*/
R=std((PSD_bat./Batchelor_spect)) * dof^0.5;

%s_fig3;


%-----------------batfit.m ends-----------------------------------------------*/
